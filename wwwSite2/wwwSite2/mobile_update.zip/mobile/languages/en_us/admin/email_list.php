<?php

/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: liubo $
 * $Id: email_list.php 17217 2011-01-19 06:29:08Z liubo $
 */
$_LANG['email_val'] = 'E-mail address';
$_LANG['stat']['name'] = 'State';
$_LANG['stat'][0] = 'Not confirmed';
$_LANG['stat'][1] = 'Has confirmed';
$_LANG['stat'][2] = 'Have to unsubscribe';
$_LANG['export'] = 'Export List';
$_LANG['id'] = 'No.';
$_LANG['button_remove'] = 'Remove';
$_LANG['button_unremove'] = 'Confirmed';
$_LANG['button_exit'] = 'Unsubscribe';
$_LANG['no_select_email'] = 'Email not selected';
$_LANG['batch_remove_succeed'] = 'Has been successfully deleted %d E-mail Address';
$_LANG['batch_unremove_succeed'] = 'Has been successfully confirmed %d E-mail Address';
$_LANG['batch_exit_succeed'] = 'Has been successfully unsubscribe %d E-mail Address';
$_LANG['back_list'] = 'Return mailing list';
?>