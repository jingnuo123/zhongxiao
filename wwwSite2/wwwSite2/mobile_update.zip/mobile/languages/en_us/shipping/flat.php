<?php

/**
 * ECSHOP Cost is fixed plug-in's language file
 * ============================================================================
 * All right reserved (C) 2005-2011 Beijing Yi Shang Interactive Technology
 * Development Ltd.
 * Web site: http://www.ecshop.com
 * ----------------------------------------------------------------------------
 * This is a free/open source software；it mean that you can modify, use and
 * republish the program code, on the premise of that your behavior is not for
 * commercial purposes.
 * ============================================================================
 * $Author: liubo $
 * $Id: flat.php 17217 2011-01-19 06:29:08Z liubo $
*/

$_LANG['flat']          = 'Intra-city shipping';
$_LANG['flat_desc']     = 'Payment method contents of cost is fixed ';
$_LANG['base_fee']      = 'Basic expenditure:';
?>