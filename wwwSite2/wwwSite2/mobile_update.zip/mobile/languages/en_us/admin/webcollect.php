<?php

/**
 * ECSHOP 网罗天下管理语言文件
 * ============================================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * $Author: testyang $
 * $Id: webcollect.php 15013 2008-10-23 09:31:42Z testyang $
 */

$_LANG['ur_here'] = 'Webcollect';
$_LANG['opened_title'] = 'You have opend the servise of webcollect,details as follows';
$_LANG['webcollect_notice'] = 'Hammer away at helping advertisers to find more spread way, make it the cheapest of, and maximize the benefits.<br />Make a search through the shopex terrace, cooperate with shopping websites, to realize the infomations of advertisers are collect by some shopping websites.';
$_LANG['support_engine'] = 'Engines supported';
$_LANG['open_now'] = 'Turn-on applications at once';
$_LANG['license_label'] = 'License';
$_LANG['period'] = 'The validity period of service';
$_LANG['to'] = 'to';
$_LANG['sev_out'] = 'Your service has expired，please contact customer service renewal';
$_LANG['soon_out'] = "Your service will expire after <font color='red'>%s</font> days";
$_LANG['included'] = 'Collected';
$_LANG['included_status'] = 'Collected details';
$_LANG['call_pay'] = 'Contact customer service renewal';
$_LANG['stop_sev'] = 'Pause the service';
$_LANG['open_sev'] = 'Opening services';
$_LANG['open_again'] = 'The open of the application again';
$_LANG['no-open'] = 'You haven`t opened the service.';
$_LANG['col_goods_num'] = 'merchandises';
$_LANG['item'] = 'items';

/* JS提示 */
$_LANG['js_languages']['sev_stop'] = 'After you pause the service，your shop、commodity information will stop an update to the search engine，sure you want to pause?？';

?>