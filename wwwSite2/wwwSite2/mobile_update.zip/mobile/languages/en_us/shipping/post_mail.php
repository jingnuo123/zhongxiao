<?php

/**
 * ECSHOP Common mailing plug-in's language file
 * ============================================================================
 * All right reserved (C) 2005-2011 Beijing Yi Shang Interactive Technology
 * Development Ltd.
 * Web site: http://www.ecshop.com
 * ----------------------------------------------------------------------------
 * This is a free/open source software；it mean that you can modify, use and
 * republish the program code, on the premise of that your behavior is not for
 * commercial purposes.
 * ============================================================================
 * $Author: liubo $
 * $Id: post_mail.php 17217 2011-01-19 06:29:08Z liubo $
*/

$_LANG['post_mail']          = 'Common mailing';
$_LANG['post_mail_desc']     = 'Common mailing\'s description';
$_LANG['pack_fee']           = 'Packing money:';
$_LANG['base_fee']          = 'Cost less than 1000g:';
$_LANG['item_fee']           = 'Single commodity costs:';
$_LANG['step_fee']          = 'Less than 5000g, cost of every 1000g:';
$_LANG['step_fee1']          = 'More than 5001g, cost of every 1000g:';

?>