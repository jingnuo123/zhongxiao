<?php

/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: liubo $
 * $Id: article_auto.php 17217 2011-01-19 06:29:08Z liubo $
 */

$_LANG['id'] = 'No.';

$_LANG['starttime'] = 'Published';
$_LANG['endtime'] = 'The abolition of time';
$_LANG['goods_name'] = 'Article name';
$_LANG['ok'] = 'Determine';
$_LANG['edit_ok'] = 'Successful operation';
$_LANG['delete'] = 'Revocation';
$_LANG['deleteck'] = 'Delete this article to determine the automatic publish // unpublish handle it? This action will not affect the article itself';
$_LANG['enable_notice'] = 'You need to system settings -> plans to open mission in order to use this feature.';
$_LANG['button_start'] = 'Batch Release';
$_LANG['button_end'] = 'Volume Unpublishing';

$_LANG['no_select_goods'] = 'No article selected';

$_LANG['batch_start_succeed'] = 'Batch successfully posted';
$_LANG['batch_end_succeed'] = 'Cancel Batch success';

$_LANG['back_list'] = 'Published article automatically return';
$_LANG['select_time'] = 'Please select the time';

?>
