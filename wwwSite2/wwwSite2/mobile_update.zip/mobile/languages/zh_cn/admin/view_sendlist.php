<?php

/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: liubo $
 * $Id: view_sendlist.php 17217 2011-01-19 06:29:08Z liubo $
 */

$_LANG['email_val'] = '邮件地址';
$_LANG['email_error'] = '错误次数';
$_LANG['email_subject'] = '邮件标题';
$_LANG['delete'] = '删除';
$_LANG['ckdelete'] = '确定删除?';
$_LANG['del_ok'] = '删除成功!';
$_LANG['no_select'] = '未选择对象!';
$_LANG['last_send'] = '上次发送';
$_LANG['pri']['name'] = '优先级';
$_LANG['pri'][0] = '普通';
$_LANG['pri'][1] = '高';
$_LANG['type']['name'] = '邮件类型';
$_LANG['type']['magazine'] = '杂志订阅';
$_LANG['type']['template'] = '关注订阅';
$_LANG['button_remove'] = '删除';
$_LANG['batch_send'] = '选择发送';
$_LANG['all_send'] = '全部发送';
$_LANG['mailsend_null'] = '邮件发送列表空!';
$_LANG['mailsend_finished'] = '全部邮件发送完成!';
$_LANG['send_end'] = '选择邮件发送完成!';
?>