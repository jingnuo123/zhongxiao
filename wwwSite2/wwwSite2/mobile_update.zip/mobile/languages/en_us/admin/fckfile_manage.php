<?php
/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: liubo $
 * $Id: fckfile_manage.php 17217 2011-01-19 06:29:08Z liubo $
 */
$_LANG['fckfile_manage'] = 'Fck From document management';
$_LANG['file_manage'] = 'File directory management';
$_LANG['image_manage'] = 'Picture directory management';
$_LANG['flash_manage'] = 'FLASH Catalog Management';
$_LANG['media_manage'] = 'Multimedia Contents Management';
$_LANG['fck_file_list'] = 'FCK Directory listing';
$_LANG['file_id'] = 'No.';
$_LANG['button_remove'] = 'Bulk delete';
$_LANG['no_select_file'] = 'You do not select any document';
$_LANG['back_list'] = 'Return the list of files';
$_LANG['batch_remove_succeed'] = 'You have successfully deleted %d files';

$_LANG['edit'] = 'Editor';
$_LANG['item_url'] = 'Link Address';
$_LANG['item_vieworder'] = 'Sort';
$_LANG['top'] = 'Top';
$_LANG['middle'] = 'Between';
$_LANG['bottom'] = 'Bottom';
$_LANG['edit_ok'] = 'Successful operation';
$_LANG['go_list'] = 'Return list';
$_LANG['ckdel'] = 'Determine the delete?';

$_LANG['namecannotnull'] = 'Please enter the name of the navigation bar!';
$_LANG['linkcannotnull'] = 'Please enter the link!';

$_LANG['notice_url'] = 'If this site are the Web site may be the initials for the root directory of the relative address Shopping Mall，Such as index.php；<br>Other circumstances should enter the full URL, such as http://www.ecshop.com/';
?>